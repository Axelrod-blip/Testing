import os
import logging
from dotenv import load_dotenv
from aiogram import Bot

load_dotenv() # Загружаем переменные из .env файла

# Получаем токены и URL из переменных окружения
BOT_TOKEN = os.getenv("BOT_TOKEN")
DATABASE_URL = os.getenv("DATABASE_URL")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Проверяем, что переменные окружения заданы
if not BOT_TOKEN:
    raise ValueError("Необходимо установить BOT_TOKEN в .env")
if not DATABASE_URL:
    raise ValueError("Необходимо установить DATABASE_URL в .env")

# API ключ OpenAI или Google API должен быть установлен
if not OPENAI_API_KEY and not GOOGLE_API_KEY:
    logging.warning("Ни OPENAI_API_KEY, ни GOOGLE_API_KEY не установлены. Функции генерации будут недоступны.")

bot = Bot(token=BOT_TOKEN)



